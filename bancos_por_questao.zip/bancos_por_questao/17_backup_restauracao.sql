-- Questao 17: Banco de exemplo para exportar/importar pelo phpMyAdmin
CREATE DATABASE IF NOT EXISTS questao_17_backup;
USE questao_17_backup;
CREATE TABLE categorias (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(80) NOT NULL
);
CREATE TABLE produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 categoria_id INT,
 nome VARCHAR(120) NOT NULL,
 FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);
INSERT INTO categorias (nome) VALUES ('Informatica');
INSERT INTO produtos (categoria_id, nome) VALUES (1, 'Teclado');
-- Exporte este banco em SQL pelo phpMyAdmin e importe o arquivo em outra maquina.
