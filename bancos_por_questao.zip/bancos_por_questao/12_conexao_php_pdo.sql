-- Questao 12: Banco para testar conexao PDO
CREATE DATABASE IF NOT EXISTS questao_12_pdo;
USE questao_12_pdo;
CREATE TABLE clientes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE
);
INSERT INTO clientes (nome, email)
VALUES ('Cliente Teste', 'teste@example.com');
