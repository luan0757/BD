-- Questao 8: INSERT, SELECT, UPDATE e DELETE
CREATE DATABASE IF NOT EXISTS questao_08_dml;
USE questao_08_dml;
CREATE TABLE tarefas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 titulo VARCHAR(120) NOT NULL,
 concluida BOOLEAN NOT NULL DEFAULT FALSE
);
INSERT INTO tarefas (titulo) VALUES ('Estudar SQL'), ('Praticar PHP');
SELECT * FROM tarefas WHERE concluida = FALSE ORDER BY titulo LIMIT 10;
UPDATE tarefas SET concluida = TRUE WHERE id = 1;
-- Confira o id antes de executar DELETE.
DELETE FROM tarefas WHERE id = 2;
