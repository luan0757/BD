-- Questao 13: CRUD completo de cadastro
CREATE DATABASE IF NOT EXISTS questao_13_crud;
USE questao_13_crud;
CREATE TABLE contatos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 telefone VARCHAR(20),
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- CREATE: INSERT INTO contatos (nome,email) VALUES ('Joao','joao@example.com');
-- READ:   SELECT * FROM contatos;
-- UPDATE: UPDATE contatos SET telefone='11999999999' WHERE id=1;
-- DELETE: DELETE FROM contatos WHERE id=1;
