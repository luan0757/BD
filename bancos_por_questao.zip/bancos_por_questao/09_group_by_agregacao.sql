-- Questao 9: GROUP BY, COUNT, SUM e AVG
CREATE DATABASE IF NOT EXISTS questao_09_agregacao;
USE questao_09_agregacao;
CREATE TABLE vendas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 vendedor VARCHAR(100) NOT NULL,
 valor DECIMAL(10,2) NOT NULL
);
INSERT INTO vendas (vendedor, valor) VALUES
 ('Ana', 100.00), ('Ana', 150.00), ('Bruno', 200.00);
SELECT vendedor, COUNT(*) AS quantidade,
       SUM(valor) AS total_vendido, AVG(valor) AS media
FROM vendas
GROUP BY vendedor
HAVING SUM(valor) >= 200;
