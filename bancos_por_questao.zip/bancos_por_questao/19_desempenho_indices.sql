-- Questao 19: Indices e organizacao para muitos registros
CREATE DATABASE IF NOT EXISTS questao_19_desempenho;
USE questao_19_desempenho;
CREATE TABLE clientes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL,
 cidade VARCHAR(80)
);
CREATE TABLE pedidos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 cliente_id INT NOT NULL,
 data_pedido DATE NOT NULL,
 total DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (cliente_id) REFERENCES clientes(id),
 INDEX idx_pedidos_data (data_pedido),
 INDEX idx_pedidos_cliente_data (cliente_id, data_pedido)
);
CREATE INDEX idx_clientes_email ON clientes(email);
-- Indices aceleram buscas, mas ocupam espaco e tornam escritas um pouco mais lentas.
