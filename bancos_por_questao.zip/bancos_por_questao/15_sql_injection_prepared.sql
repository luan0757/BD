-- Questao 15: Dados para demonstrar consulta segura com prepared statement
CREATE DATABASE IF NOT EXISTS questao_15_injection;
USE questao_15_injection;
CREATE TABLE usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 usuario VARCHAR(50) NOT NULL UNIQUE,
 senha_hash VARCHAR(255) NOT NULL
);
INSERT INTO usuarios (usuario, senha_hash)
VALUES ('aluno', 'hash_de_exemplo_nao_usar_em_producao');
-- No PHP, use PDO: $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE usuario = :usuario');
-- $stmt->execute(['usuario' => $usuario]); Nunca concatene entrada do usuario ao SQL.
