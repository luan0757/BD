-- Questao 16: Banco para demonstrar exclusao com seguranca
CREATE DATABASE IF NOT EXISTS questao_16_seguranca;
USE questao_16_seguranca;
CREATE TABLE publicacoes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 titulo VARCHAR(150) NOT NULL,
 conteudo TEXT NOT NULL,
 autor_id INT NOT NULL
);
INSERT INTO publicacoes (titulo, conteudo, autor_id)
VALUES ('Publicacao de teste', 'Texto de exemplo', 1);
-- A aplicacao deve escapar a saida HTML com htmlspecialchars().
-- Para excluir, exigir POST, autorizacao e confirmacao; usar WHERE id = ?.
-- Conceda ao usuario do banco somente os privilegios necessarios.
