-- Questao 14: Campos e restricoes que complementam a validacao PHP/HTML
CREATE DATABASE IF NOT EXISTS questao_14_validacao;
USE questao_14_validacao;
CREATE TABLE cadastros (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(80) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 idade TINYINT UNSIGNED NOT NULL,
 salario DECIMAL(10,2),
 CHECK (idade BETWEEN 1 AND 120),
 CHECK (salario IS NULL OR salario >= 0)
);
