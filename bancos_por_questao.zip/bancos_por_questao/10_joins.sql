-- Questao 10: INNER JOIN e LEFT JOIN
CREATE DATABASE IF NOT EXISTS questao_10_joins;
USE questao_10_joins;
CREATE TABLE clientes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL
);
CREATE TABLE pedidos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 cliente_id INT,
 valor DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);
INSERT INTO clientes (nome) VALUES ('Lia'), ('Caio'), ('Bia');
INSERT INTO pedidos (cliente_id, valor) VALUES (1, 80.00), (1, 45.00), (2, 120.00);
-- Mostra somente clientes que possuem pedidos:
SELECT c.nome, p.id AS pedido, p.valor
FROM clientes c INNER JOIN pedidos p ON p.cliente_id = c.id;
-- Mostra todos os clientes, inclusive quem nao fez pedido:
SELECT c.nome, p.id AS pedido, p.valor
FROM clientes c LEFT JOIN pedidos p ON p.cliente_id = c.id;
