-- Questao 18: Banco para testar cadastro, edicao, exclusao e erros
CREATE DATABASE IF NOT EXISTS questao_18_testes;
USE questao_18_testes;
CREATE TABLE departamentos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(80) NOT NULL UNIQUE
);
CREATE TABLE funcionarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 departamento_id INT NOT NULL,
 nome VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 FOREIGN KEY (departamento_id) REFERENCES departamentos(id)
);
INSERT INTO departamentos (nome) VALUES ('Tecnologia');
INSERT INTO funcionarios (departamento_id, nome, email)
VALUES (1, 'Pessoa Teste', 'pessoa@example.com');
-- Teste FK inexistente, email duplicado, campos obrigatorios e CRUD.
