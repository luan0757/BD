-- Questao 3: Exemplos 1:1, 1:N e N:N
CREATE DATABASE IF NOT EXISTS questao_03_relacionamentos;
USE questao_03_relacionamentos;

-- 1:1: cada usuario possui um perfil
CREATE TABLE usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 login VARCHAR(50) UNIQUE NOT NULL
);
CREATE TABLE perfis (
 id INT AUTO_INCREMENT PRIMARY KEY,
 usuario_id INT UNIQUE NOT NULL,
 biografia VARCHAR(255),
 FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- 1:N: um departamento possui varios funcionarios
CREATE TABLE departamentos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(80) NOT NULL
);
CREATE TABLE funcionarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 departamento_id INT NOT NULL,
 FOREIGN KEY (departamento_id) REFERENCES departamentos(id)
);

-- N:N: alunos cursam varias disciplinas; tabela associativa matriculas
CREATE TABLE alunos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL
);
CREATE TABLE disciplinas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL
);
CREATE TABLE matriculas (
 aluno_id INT NOT NULL,
 disciplina_id INT NOT NULL,
 data_matricula DATE NOT NULL,
 PRIMARY KEY (aluno_id, disciplina_id),
 FOREIGN KEY (aluno_id) REFERENCES alunos(id),
 FOREIGN KEY (disciplina_id) REFERENCES disciplinas(id)
);
