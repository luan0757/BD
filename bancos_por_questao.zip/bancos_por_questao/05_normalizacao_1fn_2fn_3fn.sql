-- Questao 5: Estrutura normalizada ate 3FN
CREATE DATABASE IF NOT EXISTS questao_05_normalizacao;
USE questao_05_normalizacao;

CREATE TABLE clientes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 email VARCHAR(150) UNIQUE
);
CREATE TABLE produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL,
 preco DECIMAL(10,2) NOT NULL
);
CREATE TABLE vendas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 cliente_id INT NOT NULL,
 data_venda DATE NOT NULL,
 FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);
-- Tabela associativa: cada linha representa um produto de uma venda.
CREATE TABLE itens_venda (
 venda_id INT NOT NULL,
 produto_id INT NOT NULL,
 quantidade INT NOT NULL,
 preco_unitario DECIMAL(10,2) NOT NULL,
 PRIMARY KEY (venda_id, produto_id),
 FOREIGN KEY (venda_id) REFERENCES vendas(id),
 FOREIGN KEY (produto_id) REFERENCES produtos(id)
);
