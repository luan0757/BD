-- Questao 6: Banco de exemplo para testar MySQL/MariaDB no XAMPP
CREATE DATABASE IF NOT EXISTS questao_06_xampp;
USE questao_06_xampp;
CREATE TABLE teste_conexao (
 id INT AUTO_INCREMENT PRIMARY KEY,
 mensagem VARCHAR(100) NOT NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO teste_conexao (mensagem) VALUES ('Conexao com o banco funcionando');
SELECT * FROM teste_conexao;
