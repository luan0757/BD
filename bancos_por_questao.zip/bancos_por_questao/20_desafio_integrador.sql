-- Questao 20: Mini-projeto integrador - loja
CREATE DATABASE IF NOT EXISTS questao_20_integrador;
USE questao_20_integrador;
CREATE TABLE clientes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE
);
CREATE TABLE produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(120) NOT NULL,
 preco DECIMAL(10,2) NOT NULL
);
CREATE TABLE pedidos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 cliente_id INT NOT NULL,
 data_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);
CREATE TABLE itens_pedido (
 pedido_id INT NOT NULL,
 produto_id INT NOT NULL,
 quantidade INT NOT NULL,
 preco_unitario DECIMAL(10,2) NOT NULL,
 PRIMARY KEY (pedido_id, produto_id),
 FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
 FOREIGN KEY (produto_id) REFERENCES produtos(id)
);
INSERT INTO clientes (nome,email) VALUES ('Maria','maria@example.com');
INSERT INTO produtos (nome,preco) VALUES ('Mouse',59.90), ('Teclado',99.90);
INSERT INTO pedidos (cliente_id) VALUES (1);
INSERT INTO itens_pedido (pedido_id,produto_id,quantidade,preco_unitario)
VALUES (1,1,1,59.90), (1,2,1,99.90);
-- Consulta com JOIN:
SELECT c.nome AS cliente, p.id AS pedido, pr.nome AS produto,
       i.quantidade, i.preco_unitario
FROM pedidos p
JOIN clientes c ON c.id = p.cliente_id
JOIN itens_pedido i ON i.pedido_id = p.id
JOIN produtos pr ON pr.id = i.produto_id;
