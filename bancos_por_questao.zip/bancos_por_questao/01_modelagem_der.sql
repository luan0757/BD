-- Questao 1: Sistema de biblioteca (entidades e atributos)
CREATE DATABASE IF NOT EXISTS questao_01_biblioteca;
USE questao_01_biblioteca;

CREATE TABLE leitores (
  id_leitor INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE,
  telefone VARCHAR(20)
);

CREATE TABLE livros (
  id_livro INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(150) NOT NULL,
  autor VARCHAR(100) NOT NULL,
  ano_publicacao YEAR
);

CREATE TABLE emprestimos (
  id_emprestimo INT AUTO_INCREMENT PRIMARY KEY,
  id_leitor INT NOT NULL,
  id_livro INT NOT NULL,
  data_emprestimo DATE NOT NULL,
  data_devolucao DATE,
  FOREIGN KEY (id_leitor) REFERENCES leitores(id_leitor),
  FOREIGN KEY (id_livro) REFERENCES livros(id_livro)
);
