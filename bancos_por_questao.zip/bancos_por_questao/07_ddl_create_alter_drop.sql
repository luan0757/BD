-- Questao 7: DDL - CREATE, ALTER e DROP
CREATE DATABASE IF NOT EXISTS questao_07_ddl;
USE questao_07_ddl;
CREATE TABLE categorias (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(80) NOT NULL
);
CREATE TABLE produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 categoria_id INT,
 nome VARCHAR(120) NOT NULL,
 preco DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);
ALTER TABLE produtos ADD COLUMN ativo BOOLEAN NOT NULL DEFAULT TRUE;
-- DROP TABLE produtos; -- descomente somente se quiser apagar a tabela.
