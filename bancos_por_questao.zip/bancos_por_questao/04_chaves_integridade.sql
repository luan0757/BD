-- Questao 4: PK, FK e integridade referencial
CREATE DATABASE IF NOT EXISTS questao_04_chaves;
USE questao_04_chaves;

CREATE TABLE clientes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL
);
CREATE TABLE pedidos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 cliente_id INT NOT NULL,
 data_pedido DATE NOT NULL,
 FOREIGN KEY (cliente_id) REFERENCES clientes(id)
   ON DELETE RESTRICT ON UPDATE CASCADE
);
-- RESTRICT impede apagar cliente com pedidos relacionados.
-- CASCADE propaga alteracao da chave. SET NULL exigiria FK anulavel.
